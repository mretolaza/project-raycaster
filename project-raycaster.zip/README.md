﻿# project-raycaster

Proyecto Final Gráficas por Computadora 

* Sprites se encuentran en la carpeta: Sprites 

* Walls se encuentran en la carpeta: Walls

* Player se encuentra en la carpeta: Player 


# Objetivo del juego 


- Descripción: 

